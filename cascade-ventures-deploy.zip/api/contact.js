// Vercel serverless function: receives form submissions and emails them via Resend.
// Required environment variables: RESEND_API_KEY, CONTACT_TO_EMAIL, CONTACT_FROM_EMAIL
const MAX_FIELD = 5000;
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const KINDS = ["Quote request", "Free visibility audit"];

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "Method not allowed" });
  const { RESEND_API_KEY, CONTACT_TO_EMAIL, CONTACT_FROM_EMAIL } = process.env;
  if (!RESEND_API_KEY || !CONTACT_TO_EMAIL || !CONTACT_FROM_EMAIL) {
    return res.status(500).json({ ok: false, error: "Form is not configured" });
  }
  const body = typeof req.body === "string" ? safeParse(req.body) : req.body;
  if (!body || typeof body.fields !== "object" || body.fields === null || !KINDS.includes(body.form)) {
    return res.status(400).json({ ok: false, error: "Invalid request" });
  }
  // Basic spam check: submissions faster than 2.5 seconds are rejected.
  if (typeof body.elapsed === "number" && body.elapsed < 2500) {
    return res.status(400).json({ ok: false, error: "Invalid request" });
  }
  const fields = {};
  for (const [k, v] of Object.entries(body.fields)) {
    if (typeof v !== "string" || k.length > 60 || v.length > MAX_FIELD) {
      return res.status(400).json({ ok: false, error: "Invalid field" });
    }
    fields[k.replace(/[\r\n]/g, " ")] = v;
  }
  if (!EMAIL_RE.test(fields.Email || "")) return res.status(400).json({ ok: false, error: "Invalid email" });

  const text = Object.entries(fields).map(([k, v]) => `${k}: ${v}`).join("\n");
  const subject = `Cascade Ventures: ${body.form} from ${(fields.Business || "website").slice(0, 80).replace(/[\r\n]/g, " ")}`;
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from: CONTACT_FROM_EMAIL, to: [CONTACT_TO_EMAIL], reply_to: fields.Email, subject, text }),
    });
    if (!r.ok) return res.status(502).json({ ok: false, error: "Email provider error" });
    return res.status(200).json({ ok: true });
  } catch {
    return res.status(502).json({ ok: false, error: "Email provider unreachable" });
  }
}

function safeParse(s) { try { return JSON.parse(s); } catch { return null; } }
